var searchData=
[
  ['del_5fgenome',['del_genome',['../classpopulation.html#af3d0b8c13b506e8013d2744646a06e52',1,'population']]],
  ['deltafitness',['DELTAFITNESS',['../_g_a__parameters_8h.html#a352de718c369636bd5f8e67c5de7a273',1,'GA_parameters.h']]]
];
