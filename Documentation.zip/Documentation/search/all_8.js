var searchData=
[
  ['nbgene',['NBGENE',['../_g_a__parameters_8h.html#a4b9448af45edcbf08658335c479cef16',1,'GA_parameters.h']]],
  ['nbgenome',['NBGENOME',['../_g_a__parameters_8h.html#a0255824c6155fa1eb84cfabb81593436',1,'GA_parameters.h']]]
];
