var searchData=
[
  ['_7egenome',['~genome',['../classgenome.html#a9c5c746ca4dde80ace6c23a471de9bff',1,'genome']]],
  ['_7epopulation',['~population',['../classpopulation.html#a6ba6cfda62b8534be70ae3945a906d05',1,'population']]]
];
