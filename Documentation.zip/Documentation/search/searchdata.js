var indexSectionsWithContent =
{
  0: "acdefgimnprstu~",
  1: "gp",
  2: "gmp",
  3: "acdfgimpstu~",
  4: "cdemnrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Macros"
};

